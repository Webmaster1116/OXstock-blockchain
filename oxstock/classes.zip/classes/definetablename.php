<?php



/* * Define Table Names * */

define('TB_USERS', 'users');

define('TB_USERS_GROUPS', 'users_groups');

define('TB_USERS_PERMISSION', 'users_permission');

define('TB_USERS_LOGINS', 'users_logins');

define('TB_USERS_LOGIN_HISTORIES', 'users_login_histories');

define('TB_LOCATIONS', 'locations');

define('TB_STATE', 'state');

define('TB_CITY', 'city');



define('TB_USER', 'user');

define('TB_SETTING', 'setting');

define('TB_OUR_BENIFITS', 'our_benifits');

define('TB_HOME_CONTENT', 'home_content');

define('TB_SUBSCRIBE', 'subscribe');

/*define('TB_JOB', 'job');

define('TB_COMPANY', 'company');

define('TB_NOTICES', 'notices');

define('TB_CLOCK', 'clock');

define('TB_TASKS', 'tasks');

define('TB_TASKS_STATUS', 'task_status');

define('TB_CHAT', 'chat');*/

define('TB_CATEGORIES', 'categories');

define('TB_AUTHOR', 'author');

define('TB_SUB_CATEGORIES', 'sub_categories');

define('TB_FAQ', 'faq');

define('TB_GALLERY', 'gallery');

define('TB_TEAM', 'team');

define('TB_HISTORY', 'history');

define('TB_BRAND', 'brand');

define('TB_BLOGS', 'blogs');
define('TB_NEWS', 'news');

define('TB_TESTIMONIAL', 'testimonial');

define('TB_SLIDER', 'slider');

define('TB_PRO_SLIDER', 'pro_slider');

define('TB_OUR_CLIENTS', 'our_clients');

define('TB_CMSPAGES', 'cmspages');

define('TB_INQUIRY', 'inquiry');

define('TB_PRODUCTS', 'products');

define('TB_PRODUCTS_IMAGES', 'products_images');

define('TB_SERVICE', 'service');

define('TB_ITEM', 'item');

define('TB_ITEM_IMAGE', 'item_image');

define('TB_CLIENT', 'client');

define('TB_CART', 'cart');

define('TB_CART_QUOTE', 'cart_quote');

define('TB_INVOICE', 'invoice');

define('TB_QUOTE', 'quote');



define('TB_TRACKER', 'tracker');

define('TB_NOTIFICATIONS', 'notification' );

define('TB_EMAIL_FORMAT', 'email_format' );