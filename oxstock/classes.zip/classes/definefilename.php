<?php

    define('AJAX','ajax.php');    

    define('DEFAULTPAGE','home.php');	

	define('FORGOT_PASSWORD','forgot-password.php');

	define('USER_LOGIN','user-login.php');

	define('REGISTER','register.php');

//	define('INDEX','index.php');	

	define('LOGOUT','logout.php');	

//	define('FLYERS','flyers.php');	
	
	define('PROFILE','profile.php');	
	
	define('SEO_ABOUTUS','about-us');
	define('ABOUTUS','about-us.php');  
	
	define('SEO_CONTACT','contact');
	define('CONTACT','contact.php');  
	
 	define('SEO_NEWSDETAIL','news-detail');
 	define('NEWSDETAIL','news-detail.php'); 
 	
	
	define('SEO_PRODUCT','product');
	define('PRODUCT','product.php'); 
	
	define('SEO_PRODUCTDETAIL','product-detail');
	define('PRODUCTDETAIL','product-detail.php'); 
	
	define('SEO_CATEGORY','category');
	define('CATEGORY','category.php'); 
	
	define('SEO_CATEGORYDETAIL','category-detail');
	define('CATEGORYDETAIL','category-detail.php'); 
	
	define('SEO_INDEX','index');
	define('INDEX','index.php');	

	define('SEO_BLOGDETAIL','blog-detail.php');
	
	

