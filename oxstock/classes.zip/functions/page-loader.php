<div class="pageloader" id="pageloader"></div>
<div class="loader" id="loader">Please wait loading...</div>
<script type="text/javascript">startloader();</script>