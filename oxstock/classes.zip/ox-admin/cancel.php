<?php require_once 'classes/configure.php'; ?>
<?php include('includes/header.php');?>
		
		
		<!-- Banner Area Start -->
		<section class="banner-area text-left">	
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="banner-content-wrapper">
                            <div class="banner-content">
                                <h2>Cancel Payment</h2>
                                <div class="banner-breadcrumb">
                                    <ul>
                                        <li><a href="<?php echo 'http://'.$_SERVER['HTTP_HOST'].str_replace($_SERVER['DOCUMENT_ROOT'],'', dirname($_SERVER['SCRIPT_FILENAME'])); ?>">home </a> <i class="zmdi zmdi-chevron-right"></i></li>
                                        <li>Cancel Payment</li>
                                    </ul>
                                </div>
                            </div>  
                        </div> 
                    </div>
                </div>
            </div>
		</section>
		<!-- Banner Area End -->
        
        <section class="about-area pt-95 pb-95 res-pb40">
           <div class="container">
           
           		 <div class="row">
                   <div class="col-md-12 col-sm-12 col-xs-12">
                       <div class="about-content usebout pt-60 res-40">
                            <h3 class="text-center pb-40">Payment Cancel</h3>
                            <p>Please Try again.</p>
                       </div>
                   </div>
				</div>
           
           </div>
        </section>
<?php include('includes/footer.php');?>