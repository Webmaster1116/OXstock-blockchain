<meta charset="UTF-8">
<title><?php echo SITENAME; ?> ADMIN</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>libs/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>assets/fonts/line-awesome/css/line-awesome.min.css">
<!--<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>assets/fonts/open-sans/styles.css">-->

<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>assets/fonts/montserrat/styles.css">

<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>libs/tether/css/tether.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>libs/jscrollpane/jquery.jscrollpane.css">
<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>libs/flag-icon-css/css/flag-icon.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>assets/styles/common.min.css">
<!-- END GLOBAL MANDATORY STYLES -->

<!-- BEGIN THEME STYLES -->
<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>assets/styles/themes/primary.min.css">
<link class="ks-sidebar-dark-style" rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>assets/styles/themes/sidebar-black.min.css">
<!-- END THEME STYLES -->

<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>assets/fonts/kosmo/styles.css">
<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>assets/fonts/weather/css/weather-icons.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>libs/c3js/c3.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>libs/noty/noty.css">
<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>assets/styles/widgets/payment.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>assets/styles/widgets/panels.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>assets/styles/dashboard/tabbed-sidebar.min.css">


<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>assets/styles/pricing/plans.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>assets/styles/apps/mail.min.css">

<!-- Validaction -->
<link rel="stylesheet" href="<?php echo URL_BASEADMIN; ?>validtips/src/tip-red/tip-red.css" />

<!-- Pagination -->
<!--<link rel="stylesheet" href="<?php echo URL_BASEADMIN; ?>pagination/font-awesome.css" />
<link rel="stylesheet" href="<?php echo URL_BASEADMIN; ?>pagination/site-bootstrap.css" />-->

<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>libs/izi-modal/css/iziModal.min.css"> <!-- Original -->
<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN; ?>assets/styles/libs/izi-modal/izi-modal.min.css"> <!-- Original -->

<link rel="stylesheet" type="text/css" href="<?php echo URL_BASEADMIN.DIR_FANCYBOX; ?>dist/jquery.fancybox.min.css">
