<script src="<?php echo URL_BASEADMIN; ?>libs/jquery/jquery.min.js"></script>
<script src="<?php echo URL_BASEADMIN; ?>libs/responsejs/response.min.js"></script>
<script src="<?php echo URL_BASEADMIN; ?>libs/loading-overlay/loadingoverlay.min.js"></script>
<script src="<?php echo URL_BASEADMIN; ?>libs/tether/js/tether.min.js"></script>
<script src="<?php echo URL_BASEADMIN; ?>libs/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo URL_BASEADMIN; ?>libs/jscrollpane/jquery.jscrollpane.min.js"></script>
<script src="<?php echo URL_BASEADMIN; ?>libs/jscrollpane/jquery.mousewheel.js"></script>
<script src="<?php echo URL_BASEADMIN; ?>libs/flexibility/flexibility.js"></script>
<script src="<?php echo URL_BASEADMIN; ?>libs/noty/noty.min.js"></script>
<script src="<?php echo URL_BASEADMIN; ?>libs/velocity/velocity.min.js"></script>

<!-- BEGIN THEME LAYOUT SCRIPTS -->
<script src="<?php echo URL_BASEADMIN; ?>assets/scripts/common.min.js"></script>
<!-- END THEME LAYOUT SCRIPTS -->

<div class="ks-mobile-overlay"></div>
<script src="<?php echo URL_BASEADMIN; ?>validtips/jquery.mjstip.js"></script>
<?php include(DIR_BASEADMIN.DIR_FUNCTIONS.'jsfunction.php'); ?>
<script src="<?php echo URL_BASEADMIN; ?>libs/tether/js/tether.min.js"></script>
<script src="<?php echo URL_BASEADMIN; ?>libs/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo URL_BASEADMIN; ?>libs/izi-modal/js/iziModal.min.js"></script>  
<script src="<?php echo URL_BASEADMIN.DIR_FANCYBOX; ?>dist/jquery.fancybox.min.js"></script>   
<script src="<?php echo URL_BASEADMIN; ?>ckeditor/ckeditor.js"></script>
<?php echo session(); ?>
<div id="my-alert" class="my-alert"></div>

<script type="text/javascript">
     $("#dropdownToggle").click(function(){
             $("#dropdownToggle").toggleClass("show");
     });
</script>