<?php

	include('script_top.php'); 		

	

	if($_REQUEST['ptype']=='list')

	{

		if($_REQUEST['type']=='statuschange')

		{

			$status = fetchqry('*',TB_SERVICE,array("id="=>$_REQUEST['id']));;

			if($status['status']=='0')

			{ 

				updateqry(array("status"=>1),array("id="=>$_REQUEST['id']),TB_SERVICE);

				echo '<span class="text-success" style="cursor:pointer">Active</span>';		

			}

			else

			{ 

				updateqry(array("status"=>0),array("id="=>$_REQUEST['id']),TB_SERVICE);

				echo '<span class="text-error" style="cursor:pointer">Inactive</span>';				

			}

		}

	}

?>