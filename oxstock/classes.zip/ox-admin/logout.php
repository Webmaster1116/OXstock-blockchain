<?php
	include('includes/script_top.php');
	
	$loginUser = new Login;
	$loginUser->logout();
?>