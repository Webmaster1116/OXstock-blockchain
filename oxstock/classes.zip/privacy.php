<?php 
require_once 'classes/configure.php'; 
include('header.php'); ?>
    <!---------------------- end priching ---------------->

    <!---------------------- terams and condition ---------------->
    <section class="trams_coundition">
        <div class="Container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="condition-text">
                        <h2>Privacy </h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque metus metus, porta id ipsum ac, gravida efficitur ipsum. Cras auctor ex quis neque pretium, in egestas orci convallis. Curabitur ornare fringilla dui, eget luctus ipsum varius vel. Duis ut nulla nec felis ultricies fermentum et at dui. In aliquam posuere mollis. In sit amet tincidunt urna. Duis sed pretium felis, at hendrerit libero. Fusce hendrerit justo eu lectus malesuada, ut dignissim orci suscipit. Quisque elementum, ex non viverra malesuada, ipsum metus pulvinar orci, ac lobortis mi libero quis ante. Nam tincidunt, tellus faucibus scelerisque elementum, nunc ligula viverra lectus, eget molestie sapien sem at justo. Pellentesque quis commodo neque. Etiam sed maximus purus, et accumsan magna. Nunc nulla augue, viverra a auctor non, facilisis finibus felis.</p>

                        <p>Etiam dui leo, luctus vel ipsum ultricies, ultrices porta dui. Duis lacinia dapibus nibh, a gravida leo scelerisque non. Maecenas sed luctus justo. Nulla ac vulputate magna. Nam tempus, purus quis consectetur vulputate, nulla odio gravida tortor, quis luctus tellus eros nec nisl. Donec ut nulla mi. Suspendisse eget felis mi. Fusce ac odio in magna cursus laoreet nec vel quam. Nullam tincidunt nunc non libero pretium, ac lobortis nisi pulvinar. Ut ornare tincidunt nibh eget bibendum. Cras auctor vitae metus sit amet facilisis. Quisque vehicula tellus mi, eu condimentum ligula pellentesque ac. In ornare nunc orci. Proin risus dui, luctus et laoreet sed, pellentesque eu magna.</p>

                        <p>Praesent aliquet, ipsum vel lacinia vestibulum, nisl ipsum congue lacus, in aliquam erat sem ac felis. Maecenas sodales felis magna, eu ultricies elit auctor vitae. Sed fringilla dolor id nulla rutrum, pulvinar vestibulum enim mollis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec a tincidunt eros. In sit amet vehicula libero. In lacinia, nibh in mollis tempus, urna urna vestibulum justo, ac dictum ante dui ac ligula. Mauris sollicitudin, est ut sagittis cursus, lorem ex porttitor sapien, ac pharetra purus leo vitae elit. Sed id arcu augue. Proin pulvinar ex justo, id tempus ligula dictum eget. Sed egestas varius finibus. Nulla neque turpis, luctus non faucibus sed, semper vel massa. Suspendisse potenti. Suspendisse potenti. Mauris lacinia dictum quam, at luctus leo.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!---------------------- terams and condition ---------------->

    <!---------------------- footer ---------------->
    <?php include('footer.php'); ?>