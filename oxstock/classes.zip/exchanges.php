<?php 
require_once 'classes/configure.php'; 
include('header.php'); ?>
    <!---------------------- end priching ---------------->
    <section class="cript_body">
        <div class="container">
            <img src="plugin/images/exchanges.png">
        </div>
    </section>



      <!---------------------- footer ---------------->
      <?php include('footer.php'); ?>