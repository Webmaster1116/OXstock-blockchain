<?php
require_once 'classes/configure.php'; 
include('header.php'); ?>
    <!---------------------- end priching ---------------->
    <!---------------------- sheares_pag ---------------->

    <div class="sheares_pag">
        <div class="Container">
            <div class="row">
                <div class="col-sm-8">
                    <div class="shaers-left">
                        <img src="plugin/images/shares-imggg.png">

                    </div>
                </div>
                <div class="col-sm-4">

                    <div class="shares-right">
                        <div class="top-img">
                            <img src="plugin/images/asxcc.png">
                        </div>
                        <div class="med-contain">


                            <h4><span><i class="fa fa-line-chart" aria-hidden="true"></i></span>ASX Top 5 Portfolio</h4>

                            <p>Our High-Growth ASX Strategy</p>

                            <p> <a href="#">Subscriptions start at $59 monthly</a></p>

                            <a href="#">Find Out More</a>
                        </div>
                        <div class="bottom-img">
                            <img src="plugin/images/axseeee.png">
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!---------------------- end sheares_pag ---------------->


    <!---------------------- footer ---------------->
      <?php include('footer.php'); ?>